/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicpdfgenerationprocess;

import dynamicpdfgeneration.constants.CommonVariables;
import dynamicpdfgeneration.util.PropertiesReader;
import dynamicpdfgenerationprocess.thread.DynamicPDFGenerationProcessThread;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author manoj.prithiani
 */
public class DynamicPDFGenerationProcess {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	PropertyConfigurator.configure(classLoader.getResource("logging.properties"));
         Logger logger = Logger.getLogger(DynamicPDFGenerationProcess.class);
        PropertiesReader props =new PropertiesReader();
        props.setPropertyFile(CommonVariables.propertiesDir+"DynamicPDF.properties");
        int processCount =Integer.parseInt(props.getPropertyValue("MAX_PROCESS_COUNT"));
        DynamicPDFGenerationProcessThread[] processThread =new DynamicPDFGenerationProcessThread[processCount];
        int fileCount =Integer.parseInt(props.getPropertyValue("MAX_FILE_COUNT"));
        String PDFGenerationCmd =props.getPropertyValue("PDF_GENERATION_JAR");
        String logPath =props.getPropertyValue("DPGP_LOG_PATH");
        int fileCountPerProcess= fileCount/processCount;
        String cmd =null; ;
        int startCount =0,endCount =0;
       

        for(int i=0; i< processCount; i++){
            startCount =i*fileCountPerProcess;
            if (i==(processCount -1)){
                endCount =fileCount;
            }else{
                endCount =startCount+fileCountPerProcess;
            }
            cmd =PDFGenerationCmd+ " Hadoop"+i +" "+startCount+" "+endCount; 
            logger.info("Command is :"+cmd);
            processThread[i] =new DynamicPDFGenerationProcessThread();
            processThread[i].setJvmCommand(cmd);
            processThread[i].start();           
        }
           
    }
    
}
