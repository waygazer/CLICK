/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicpdfgeneration;

import dynamicpdfgeneration.constants.CommonVariables;
import dynamicpdfgeneration.observer.DirectoryObserver;
import dynamicpdfgeneration.util.PropertiesReader;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
/**
 *
 * @author manoj.prithiani
 */
public class DynamicPDFGeneration {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
	PropertyConfigurator.configure(classLoader.getResource("logging.properties"));
        Logger logger = Logger.getLogger(DynamicPDFGeneration.class);

        String jvmName =args[0];
        int startCount =Integer.parseInt(args[1]);
        int endCount =Integer.parseInt(args[2]);
        CommonVariables.counter=startCount;
        CommonVariables.totalCount =endCount;
        PropertiesReader props =new PropertiesReader();
        props.setPropertyFile(CommonVariables.propertiesDir+"DynamicPDF.properties");
        String logPath =props.getPropertyValue("DPG_LOG_PATH");
        String outputFileLocation =props.getPropertyValue("OUTPUT_FILE_LOCATION");
        int maxThreadCount =Integer.parseInt(props.getPropertyValue("MAX_THREAD_COUNT"));
        DynamicPDFGenerationThread[] pdfGeneration =new DynamicPDFGenerationThread[maxThreadCount] ;
        DirectoryObserver observer =new DirectoryObserver();
        observer.setDir(outputFileLocation);
        observer.setStartCount(0);
        observer.setEndCount(endCount);
        observer.start();
        int perThreadCount=(endCount-startCount)/maxThreadCount;
        for(int i=0; i <maxThreadCount;i++){
           pdfGeneration[i] =new DynamicPDFGenerationThread(); 
           pdfGeneration[i].setName("PDFGenerationThread "+i);
           pdfGeneration[i].setStartCount(i*perThreadCount);
           if (i==(maxThreadCount-1)){
               pdfGeneration[i].setEndCount(endCount);
           }else{
               pdfGeneration[i].setEndCount((i*perThreadCount)+perThreadCount);
           }
           pdfGeneration[i].setDir(outputFileLocation);
           pdfGeneration[i].start();
           try {
                pdfGeneration[i].sleep(500);
            } catch (InterruptedException ex) {
              logger.warn("InterruptedException is :"+ex.getMessage());
            }
        }
        
      
       
    }  
    
    
}
