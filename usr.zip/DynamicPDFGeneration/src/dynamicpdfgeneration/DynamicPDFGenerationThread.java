/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicpdfgeneration;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import dynamicpdfgeneration.constants.CommonVariables;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author manoj.prithiani
 */
public class DynamicPDFGenerationThread extends Thread {

    private String dir = null;
    int startCount = 0;
    int endCount = 0;
    private Logger logger = null;

    public int getStartCount() {
        return startCount;
    }

    public void setStartCount(int startCount) {
        this.startCount = startCount;
    }

    public int getEndCount() {
        return endCount;
    }

    public void setEndCount(int endCount) {
        this.endCount = endCount;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public void run() {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        PropertyConfigurator.configure(classLoader.getResource("logging.properties"));
        logger = Logger.getLogger(DynamicPDFGenerationThread.class);
        int counter = startCount;
        while ((counter = CommonVariables.counter) < CommonVariables.totalCount) {
            startPDFGeneration();
        }
    }

    private void startPDFGeneration() {
        String fileName = null;
        int counter = startCount;
        Document document = null;
        Path file = null;

        if ((counter = CommonVariables.counter) < endCount) {
            try {
                fileName = getDir() + "/Hadoop" + counter + ".txt";
                document = new Document();
                /*PdfWriter.getInstance(document, new FileOutputStream(fileName));
                document.open();
                document.newPage();
                document.add(new Paragraph("This is content of " + fileName));
                 */
                String line = "This is content of " + fileName + " created by " + this.getName();
                byte data[] = line.getBytes();
                file = Paths.get(fileName);
                Files.write(file, data);
            } catch (FileNotFoundException ex) {
                logger.warn("Issue with Location " + ex.getMessage());
            } catch (IOException ex) {
                logger.warn("Issue with Location " + ex.getMessage());;
            } finally {
                document.close();
            }
            CommonVariables.counter = counter + 1;
        }
    }
}
