/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicpdfgeneration.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author manoj.prithiani
 */
public class PropertiesReader {

    Properties SystemProperties = new Properties();
    String propertyFile = null;

    public Properties getSystemProperties() {
        return SystemProperties;
    }

    public void setSystemProperties(Properties SystemProperties) {
        this.SystemProperties = SystemProperties;
    }

    public String getPropertyFile() {
        return propertyFile;
    }

    public void setPropertyFile(String propertyFile) {
        this.propertyFile = propertyFile;
    }

    public String getPropertyValue(String key) {
        InputStream istream = null;
        String value = null;
        try {
            istream = new FileInputStream(propertyFile);
            if (istream != null) {
                SystemProperties.load(istream);
                value = (String) SystemProperties.get(key);
                istream.close();
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return value;
    }
}
