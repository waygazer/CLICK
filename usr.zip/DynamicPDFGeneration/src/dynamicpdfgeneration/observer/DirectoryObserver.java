/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicpdfgeneration.observer;

import dynamicpdfgeneration.DynamicPDFGeneration;
import dynamicpdfgeneration.constants.CommonVariables;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.WatchService;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author manoj.prithiani
 */
public class DirectoryObserver extends Thread {

    private String dir = null;
    int fileCount = 0;
    int startCount = 0;
    int endCount = 0;
    private Logger logger = null;

    public int getStartCount() {
        return startCount;
    }

    public void setStartCount(int startCount) {
        this.startCount = startCount;
    }

    public int getEndCount() {
        return endCount;
    }

    public void setEndCount(int endCount) {
        this.endCount = endCount;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }

    public void run() {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        PropertyConfigurator.configure(classLoader.getResource("logging.properties"));
        logger = Logger.getLogger(DynamicPDFGeneration.class);

        while (fileCount < CommonVariables.totalCount) {
            startObserving();
        }
    }

    public int startObserving() {
        Path myDir = Paths.get(dir);
        fileCount = startCount;
        try {
            WatchService watcher = myDir.getFileSystem().newWatchService();
            myDir.register(watcher, ENTRY_CREATE);
            WatchKey watckKey = watcher.take();

            List<WatchEvent<?>> events = watckKey.pollEvents();
            for (WatchEvent event : events) {
                if (event.kind() == ENTRY_CREATE) {
                    //  System.out.println("Created: " + event.context().toString());
                    DirectoryStream<Path> directoryStream = Files.newDirectoryStream(myDir);
                    for (Path path : directoryStream) {
                        fileCount++;
                    }

                }

            }

        } catch (Exception e) {
            logger.warn("Observer Error: " + e.toString());
        }
        logger.info("File count " + fileCount);
        return fileCount;
    }
}
