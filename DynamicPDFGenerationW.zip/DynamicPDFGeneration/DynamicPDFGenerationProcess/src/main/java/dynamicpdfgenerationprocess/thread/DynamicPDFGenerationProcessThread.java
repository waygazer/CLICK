/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dynamicpdfgenerationprocess.thread;

import dynamicpdfgenerationprocess.DynamicPDFGenerationProcess;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author azureuser
 */
public class DynamicPDFGenerationProcessThread extends Thread {

    public String jvmCommand = null;

    public String getJvmCommand() {
        return jvmCommand;
    }

    public void setJvmCommand(String jvmCommand) {
        this.jvmCommand = jvmCommand;
    }

    public void run() {
        Process process = null;
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        PropertyConfigurator.configure(classLoader.getResource("logging.properties"));
        org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DynamicPDFGenerationProcess.class);
        BufferedReader in = null;
        try {
            process = Runtime.getRuntime().exec(this.getJvmCommand());
            in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = null;
            while ((line = in.readLine()) != null) {
                logger.info(line);
            }
        } catch (IOException ex) {
            logger.warn("Exception is " + ex.getMessage());
        }

    }

}
